import '../../entities/user.dart';
import '../../repositories/user_repository.dart';

class GetAllProfiles {
  final UserRepository repository;

  GetAllProfiles(this.repository);

  Future<List<User>> call() {
    return repository.getAllProfiles();
  }
}