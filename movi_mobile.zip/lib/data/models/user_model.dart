import 'package:movi_mobile/domain/entities/user.dart';

class UserModel {
  final int id;
  final String name;
  final int isAdult;
  final String? apiKey;
  final String? profileImage;

  UserModel({
    required this.id,
    required this.name,
    required this.isAdult,
    this.apiKey,
    this.profileImage,
  });

  // Convertir UserModel en entité User
  User toEntity() {
    return User(
      id: id,
      name: name,
      isAdult: isAdult,
      apiKey: apiKey,
      profileImage: profileImage,
    );
  }

  // Méthode fromEntity pour créer un UserModel à partir de User
  factory UserModel.fromEntity(User user) {
    return UserModel(
      id: user.id,
      name: user.name,
      isAdult: user.isAdult,
      apiKey: user.apiKey,
      profileImage: user.profileImage,
    );
  }

  // Factory pour créer un UserModel à partir d'une Map JSON
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      name: json['name'],
      apiKey: json['api_key'] ?? '',
      profileImage: json['profile_image'],
      isAdult: json['is_adult'],
    );
  }

  // Méthode pour convertir un UserModel en JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'api_key': apiKey,
      'profile_image': profileImage,
      'is_adult': isAdult,
    };
  }
}
