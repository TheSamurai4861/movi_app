import 'package:flutter/material.dart';
import 'package:movi_mobile/core/constants/theme/app_colors.dart';

class AddButton extends StatefulWidget {
  final double width;
  final dynamic media;
  const AddButton({super.key, required this.width, required this.media});

  @override
  State<AddButton> createState() => _AddButtonState();
}

class _AddButtonState extends State<AddButton> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          widget.media.isFavorite.value = !widget.media.isFavorite.value;
        });
      },
      child: Container(
          width: widget.width,
          height: widget.width,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(widget.width / 2),
              color: AppColors.secondary),
          child: ValueListenableBuilder<bool>(
            valueListenable: widget.media.isFavorite,
            builder: (BuildContext context, bool value, Widget? child) {
              return Center(
                child: Image.asset(
                  widget.media.isFavorite.value
                      ? 'assets/icons/added.png'
                      : 'assets/icons/add.png',
                  height: 30,
                ),
              );
            },
          )),
    );
  }
}
