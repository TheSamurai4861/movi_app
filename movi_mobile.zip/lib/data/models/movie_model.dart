import '../../domain/entities/movie.dart';

class MovieModel {
  final int tmdb;
  final String title;
  final String duration;
  final String? synopsis;
  final List<MovieCategoryModel>? categories;
  final bool? isFavorite;
  final int? timeWatched;
  final List<MovieLinkModel>? links;
  final int added;
  final String cover;
  final String coverWithText;
  final int year;
  final String backdrop;

  MovieModel(
      {required this.tmdb,
      required this.title,
      required this.duration,
      this.synopsis,
      this.categories,
      this.isFavorite,
      this.timeWatched,
      this.links,
      required this.added,
      required this.cover,
      required this.coverWithText,
      required this.year,
      required this.backdrop});

  // Méthode pour convertir en entité de domaine
  Movie toEntity() {
    return Movie(
      tmdb: tmdb,
      title: title,
      duration: duration,
      synopsis: synopsis,
      categories: categories?.map((e) => e.toEntity()).toList() ?? [],
      isFavorite: isFavorite ?? false,
      timeWatched: timeWatched ?? 0,
      links: links?.map((e) => e.toEntity()).toList() ?? [],
      added: added,
      cover: cover,
      year: year,
      coverWithText: coverWithText,
      backdrop: backdrop,
    );
  }

  // Factory method for JSON deserialization
  factory MovieModel.fromJson(Map<String, dynamic> json) {
    return MovieModel(
      tmdb: json['tmdb'],
      title: json['title'],
      duration: json['duration'],
      synopsis: json['synopsis'],
      categories: (json['categories'] as List?)
          ?.map((e) => MovieCategoryModel.fromJson(e))
          .toList(),
      isFavorite: json['is_favorite'],
      timeWatched: json['time_watched'],
      links: (json['links'] as List?)
          ?.map((e) => MovieLinkModel.fromJson(e))
          .toList(),
      added: json['added'],
      cover: json['cover'],
      coverWithText: json['coverWithText'],
      year: json['year'],
      backdrop: json['backdrop'],
    );
  }
}

class MovieCategoryModel {
  final String name;
  final int id;

  MovieCategoryModel({
    required this.name,
    required this.id,
  });

  MovieCategory toEntity() {
    return MovieCategory(
      name: name,
      id: id,
    );
  }

  factory MovieCategoryModel.fromJson(Map<String, dynamic> json) {
    return MovieCategoryModel(
      name: json['name'],
      id: json['id'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'id': id,
    };
  }
}

class MovieLinkModel {
  final String url;
  final int hoster;
  final String quality;

  MovieLinkModel({
    required this.url,
    required this.hoster,
    required this.quality,
  });

  MovieLink toEntity() {
    return MovieLink(
      url: url,
      hoster: hoster,
      quality: quality,
    );
  }

  factory MovieLinkModel.fromJson(Map<String, dynamic> json) {
    return MovieLinkModel(
      url: json['url'],
      hoster: json['hoster'] ?? 1,
      quality: json['quality'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'url': url,
      'hoster': hoster,
      'quality': quality,
    };
  }
}
