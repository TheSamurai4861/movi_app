class User {
  final int id;
  final String name;
  final String? apiKey;
  final String? profileImage;
  final int isAdult;

  User({required this.id, required this.name, this.apiKey, this.profileImage, required this.isAdult});
}
