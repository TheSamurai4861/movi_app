import '../../entities/user.dart';
import '../../repositories/user_repository.dart';

class DeleteUser {
  final UserRepository repository;

  DeleteUser(this.repository);

  Future<void> call(User user) {
    return repository.deleteUser(user);
  }
}