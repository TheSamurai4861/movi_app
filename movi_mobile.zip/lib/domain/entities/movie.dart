import 'package:flutter/material.dart';

class Movie {
  final int tmdb;
  final String cover;
  final String coverWithText;
  final String backdrop;
  final String title;
  final String duration;
  final int year;
  final ValueNotifier<bool> isFavorite;
  final List<MovieCategory> categories;
  final int added;
  int timeWatched;
  List<MovieLink>? links;
  String? synopsis;

  Movie({
    required this.tmdb,
    required this.cover,
    required this.title,
    required this.duration,
    required this.year,
    required this.coverWithText,
    required this.backdrop,
    required this.added,
    required this.categories,
    this.synopsis,
    this.links,
    this.timeWatched = 0,
    bool isFavorite = false,
  }) : isFavorite = ValueNotifier<bool>(isFavorite);
}

class MovieCategory {
  final String name;
  final int id;

  MovieCategory({required this.name, required this.id});
}

class MovieLink {
  String url;
  int hoster;
  String quality;

  MovieLink({required this.url, required this.hoster, required this.quality});
}