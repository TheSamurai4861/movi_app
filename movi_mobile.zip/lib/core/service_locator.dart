import 'package:get_it/get_it.dart';
import 'package:movi_mobile/data/datasources/local/local_database.dart';
import 'package:movi_mobile/data/datasources/local/user_local_datasource.dart';
import 'package:movi_mobile/data/datasources/remote/movie_remote_datasource.dart';
import 'package:movi_mobile/data/repositories/movie_repository_impl.dart';
import 'package:movi_mobile/domain/repositories/movie_repository.dart';
import 'package:movi_mobile/domain/repositories/user_repository.dart';
import 'package:movi_mobile/domain/usecases/movie/get_trending_movies.dart';
import 'package:movi_mobile/presentation/bloc/splash_bloc.dart';

final sl = GetIt.instance;

Future<void> init() async {
  print("Starting dependency injection initialization...");

  try {
    // final localDatabase = LocalDatabase();
    // await localDatabase.ensureDatabaseReady(); 
    // // Core
    // sl.registerLazySingleton<LocalDatabase>(() => localDatabase);

    // Data Sources
    sl.registerLazySingleton<UserLocalDataSource>(
        () => UserLocalDataSourceImpl(sl()));
    sl.registerLazySingleton<MovieRemoteDataSource>(
        () => MovieRemoteDataSourceImpl(sl()));

    // Repositories
    sl.registerLazySingleton<MovieRepository>(() => MovieRepositoryImpl(
          remoteDataSource: sl(),
        ));

    // Blocs

    sl.registerFactory(() {
      print("Registering LoadingBloc...");
      return SplashBloc(
        movieRepository: sl<MovieRepository>(),
        userRepository: sl<UserRepository>(),
      );
    });

    sl.registerLazySingleton<GetTrendingMovies>(() => GetTrendingMovies(sl<MovieRepository>()));


    print("Dependency injection initialization completed successfully.");
  } catch (e) {
    print("Error during dependency injection initialization: $e");
    rethrow; // Rejette l'exception pour aider au débogage.
  }
}
