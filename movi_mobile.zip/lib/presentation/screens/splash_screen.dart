import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:movi_mobile/presentation/bloc/splash_bloc.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Dispatch de l'événement pour charger les films
    context.read<SplashBloc>().add(LoadMoviesEvent());

    return Scaffold(
      body: BlocListener<SplashBloc, SplashState>(
        listener: (context, state) {
          if (state is SplashCompleteState) {
            Future.delayed(const Duration(seconds: 5));
            // Lorsque le chargement est terminé, on passe à la HomeScreen
            context.go('/home', extra: state.trendingMovies);
          }
        },
        child: SafeArea(
          child: Stack(
            children: [
              Center(
                child: Image.asset(
                  'assets/icons/logo.png',
                  height: 150,
                  fit: BoxFit.contain,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
