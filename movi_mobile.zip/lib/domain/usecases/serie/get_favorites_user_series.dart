import '../../entities/serie.dart';
import '../../repositories/serie_repository.dart';

class GetFavoritesUserSeries {
  final SerieRepository repository;

  GetFavoritesUserSeries(this.repository);

  Future<List<Serie>> call() {
    return repository.getFavoritesUserSeries();
  }
}