import '../../entities/serie.dart';
import '../../repositories/serie_repository.dart';

class GetNowPlayingSeries {
  final SerieRepository repository;

  GetNowPlayingSeries(this.repository);

  Future<List<Serie>> call() {
    return repository.getNowPlayingSeries();
  }
}
