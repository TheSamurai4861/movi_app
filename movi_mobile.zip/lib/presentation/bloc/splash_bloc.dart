import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:movi_mobile/core/error/failures.dart';
import 'package:movi_mobile/domain/entities/movie.dart';
import 'package:movi_mobile/domain/repositories/movie_repository.dart';
import 'package:movi_mobile/domain/repositories/user_repository.dart';
import 'package:dartz/dartz.dart'; // Assurez-vous que dartz est importé

abstract class SplashEvent {}

class LoadMoviesEvent extends SplashEvent {}

abstract class SplashState {}

class SplashInitialState extends SplashState {}

class SplashInProgressState extends SplashState {}

class SplashCompleteState extends SplashState {
  final List<Movie> trendingMovies;

  SplashCompleteState({required this.trendingMovies});
}

class UnAuthicatedState extends SplashState {}

class SplashBloc extends Bloc<SplashEvent, SplashState> {
  final MovieRepository movieRepository;
  final UserRepository userRepository;

  SplashBloc({required this.movieRepository, required this.userRepository})
      : super(SplashInitialState()) {
    print("MovieRepository: $movieRepository");
    print("UserRepository: $userRepository");

    on<LoadMoviesEvent>((event, emit) async {
      emit(SplashInProgressState());

      try {
        // Simulation d'une action légère pour tester
        print("Loading trending movies...");

        // Appel à la méthode getTrendingMovies qui retourne un Either
        Either<Failure, List<Movie>> result =
            await movieRepository.getTrendingMovies();

        result.fold(
          (failure) {
            // Gérer l'échec ici
            print("Error: $failure");
            emit(
                UnAuthicatedState()); // Vous pouvez émettre un autre état d'erreur si nécessaire
          },
          (movies) {
            // Si succès, vérifiez que la liste n'est pas vide
            if (movies.isNotEmpty) {
              emit(SplashCompleteState(trendingMovies: movies));
            } else {
              emit(UnAuthicatedState());
            }
          },
        );
      } catch (e) {
        print("Erreur lors du chargement des films : $e");
        emit(SplashInitialState());
      }
    });
  }
}
