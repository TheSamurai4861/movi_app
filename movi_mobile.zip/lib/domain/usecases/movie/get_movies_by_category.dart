import 'package:dartz/dartz.dart';

import 'package:movi_mobile/core/error/failures.dart';

import '../../entities/movie.dart';
import '../../repositories/movie_repository.dart';

class GetMoviesByCategory {
  final MovieRepository repository;

  GetMoviesByCategory(this.repository);

  Future<Either<Failure, List<Movie>>> call(MovieCategory category) {
    return repository.getMoviesByCategory(category);
  }
}
