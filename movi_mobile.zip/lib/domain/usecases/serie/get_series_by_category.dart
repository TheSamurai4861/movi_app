import '../../entities/serie.dart';
import '../../repositories/serie_repository.dart';

class GetSeriesByCategory {
  final SerieRepository repository;

  GetSeriesByCategory(this.repository);

  Future<List<Serie>> call() {
    return repository.getSeriesByCategory();
  }
}
