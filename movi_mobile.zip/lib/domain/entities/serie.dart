import 'package:flutter/material.dart';

class Serie {
  final int tmdb;
  final String cover;
  final String coverWithText;
  final String backdrop;
  final String title;
  final int numberOfSeasons;
  final int year;
  final ValueNotifier<bool> isFavorite;
  final List<Season> seasons;
  final List<SerieCategory> categories;
  final String? synopsis;

  Serie({
    required this.tmdb,
    required this.cover,
    required this.title,
    required this.numberOfSeasons,
    required this.year,
    required this.coverWithText,
    required this.backdrop,
    required this.seasons,
    required this.categories,
    this.synopsis,
    bool isFavorite = false,
  }) : isFavorite = ValueNotifier<bool>(isFavorite);
}

class Season {
  final String name;
  final List<Episode> episodes;

  Season({
    required this.name,
    required this.episodes,
  });
}

class Episode {
  final String title;
  final String cover;
  final String duration;
  final String releaseDate;
  final String? synopsis;
  final List<SerieLink>? links;

  Episode({
    required this.title,
    required this.cover,
    required this.duration,
    required this.releaseDate,
    this.synopsis,
    this.links
  });
}

class SerieCategory {
  final String name;
  final int id;

  SerieCategory({required this.name, required this.id});
}

class SerieLink {
  String url;
  int hoster;
  String quality;

  SerieLink({required this.url, required this.hoster, required this.quality});
}
