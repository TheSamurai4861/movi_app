export 'package:movi_mobile/presentation/screens/home_screen.dart';
export 'package:movi_mobile/presentation/screens/player_screen.dart';
export 'package:movi_mobile/presentation/screens/movies_screen.dart';
export 'package:movi_mobile/presentation/screens/series_screen.dart';
export 'package:movi_mobile/presentation/screens/favorites_screen.dart';
export 'package:movi_mobile/presentation/screens/splash_screen.dart';