import 'package:dartz/dartz.dart';
import '../entities/movie.dart';
import '../entities/user.dart';
import '../../core/error/failures.dart';

abstract class MovieRepository {
  Future<Either<Failure, List<Movie>>> getTrendingMovies();
  Future<Either<Failure, List<Movie>>> getMoviesByCategory(MovieCategory category);
  Future<Either<Failure, List<Movie>>> searchMovie(String query);
  Future<Either<Failure, List<Movie>>> getFavoritesUserMovies(User user);
  Future<Either<Failure, List<Movie>>> getNowPlayingMovies(User user);
  Future<Either<Failure, void>> addNewMovies();
}
