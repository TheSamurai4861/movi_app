import '../entities/user.dart';

abstract class UserRepository {
  Future<List<User>> getAllProfiles();
  Future<void> signIn(User user);
  Future<void> deleteUser(User user);
}
