import '../entities/serie.dart';

abstract class SerieRepository {
  Future<List<Serie>> getSeriesByCategory();
  Future<List<Serie>> getFavoritesUserSeries();
  Future<List<Serie>> getNowPlayingSeries();
  Future<List<Serie>> getTrendingSeries();
  Future<List<Serie>> searchSerie();
}
