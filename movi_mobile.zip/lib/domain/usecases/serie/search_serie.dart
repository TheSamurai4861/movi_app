import '../../entities/serie.dart';
import '../../repositories/serie_repository.dart';

class SearchSerie {
  final SerieRepository repository;

  SearchSerie(this.repository);

  Future<List<Serie>> call() {
    return repository.searchSerie();
  }
}
