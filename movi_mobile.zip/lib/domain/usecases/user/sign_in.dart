import '../../entities/user.dart';
import '../../repositories/user_repository.dart';

class SignIn {
  final UserRepository repository;

  SignIn(this.repository);

  Future<void> call(User user) {
    return repository.signIn(user);
  }
}