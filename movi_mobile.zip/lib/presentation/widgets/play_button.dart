import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:movi_mobile/core/constants/theme/app_colors.dart';

class PlayButton extends StatelessWidget {
  final double width;
  final double height;
  final dynamic media;
  const PlayButton(
      {super.key,
      required this.width,
      required this.height,
      required this.media});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/player', extra: [media]),
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(width / 2),
            color: AppColors.primary),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/icons/play.png',
              height: 25,
              fit: BoxFit.contain,
            ),
            const SizedBox(
              width: 20,
            ),
            const Text(
              'Regarder',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }
}
