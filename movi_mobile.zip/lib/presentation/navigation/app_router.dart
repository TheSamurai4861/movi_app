import 'package:go_router/go_router.dart';
import 'package:movi_mobile/domain/entities/movie.dart';
import 'package:movi_mobile/presentation/exports/screens.dart';

final router = GoRouter(routes: [
  GoRoute(
    path: '/home',
    builder: (context, state) {
      final trendingMovies = state.extra as List<Movie>;
      return HomeScreen(
        trendingMovies: trendingMovies,
      );
    },
  ),
  GoRoute(
    path: '/',
    builder: (context, state) => const SplashScreen(),
  ),
  GoRoute(
    path: '/player',
    builder: (context, state) {
      final mediaData = state.extra as List<dynamic>;
      final dynamic media = mediaData[0]; // Le média principal (film ou série)
      final int? season = mediaData.length > 1
          ? mediaData[1]
          : null; // Saison pour les épisodes
      final int? episode =
          mediaData.length > 2 ? mediaData[2] : null; // Épisode pour les séries

      return PlayerScreen(
        media: media,
        season: season,
        episode: episode,
      );
    },
  ),
  GoRoute(
    path: '/movies',
    builder: (context, state) => const MoviesScreen(),
  ),
  GoRoute(
    path: '/tvs',
    builder: (context, state) => const SeriesScreen(),
  ),
  GoRoute(
    path: '/fav',
    builder: (context, state) => const FavoritesScreen(),
  ),
]);
