import 'package:movi_mobile/data/datasources/local/local_database.dart';

import '../../../domain/entities/user.dart';
import '../../models/user_model.dart';

abstract class UserLocalDataSource {
  Future<List<UserModel>> getAllProfiles();
  Future<void> signIn(UserModel user);
  Future<void> deleteUser(User user);
  Future<int> getLastId();
}

class UserLocalDataSourceImpl implements UserLocalDataSource {
  final LocalDatabase db;

  UserLocalDataSourceImpl(this.db);

  @override
  Future<void> deleteUser(User user) async {
    final database = await db.database;
    await database.delete('user', where: 'user_id = ?', whereArgs: [user.id]);
  }

  @override
  Future<List<UserModel>> getAllProfiles() async {
    final database = await db.database;
    List<UserModel> users = [];
    final usersMap = await database.query('user');

    if (usersMap.isNotEmpty) {
      for (var userMap in usersMap) {
        users.add(UserModel.fromJson(userMap));
      }
    }

    return users;
  }

  @override
  Future<void> signIn(UserModel user) async {
    final database = await db.database;
    await database.insert('user', user.toJson());
  }

  @override
  Future<int> getLastId() async {
    final database = await db
        .database; // Assurez-vous que db est une instance de votre classe de base de données.

    // Exécutez la requête SQL pour obtenir le plus grand id dans la table user
    final List<Map<String, dynamic>> result =
        await database.rawQuery('SELECT MAX(id) as maxId FROM user');

    // Vérifiez si le résultat n'est pas vide et renvoyez le maxId
    if (result.isNotEmpty) {
      return result.first['maxId'] as int? ?? 0; // Renvoie 0 si maxId est nul
    } else {
      return 0; // Renvoie 0 si aucun résultat
    }
  }
}
