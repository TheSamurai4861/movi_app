import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:http/http.dart' as http;

class LocalDatabase {
  static final LocalDatabase _instance = LocalDatabase._internal();
  static Database? _database;
  static bool _isDownloading = false;

  factory LocalDatabase() {
    return _instance;
  }

  LocalDatabase._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;

    if (_isDownloading) {
      // Attendre que le téléchargement soit terminé
      await Future.doWhile(() => _isDownloading);
      return _database!;
    }

    _isDownloading = true;
    _database = await _initDatabase();
    _isDownloading = false;
    return _database!;
  }

  Future<Database> _initDatabase() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'movi.db');

    var exists = await databaseExists(path);
    if (!exists) {
      print("Base de données inexistante, téléchargement en cours...");
      await _downloadDatabaseFromUrl(path);
    } else {
      print("Ouverture de la base de données existante...");
    }

    return await openDatabase(path);
  }

  Future<void> _downloadDatabaseFromUrl(String path) async {
    try {
      final url = Uri.parse("");
      final response = await http.get(url);

      if (response.statusCode == 200) {
        await Directory(dirname(path)).create(recursive: true);
        await File(path).writeAsBytes(response.bodyBytes, flush: true);
        print("Base de données téléchargée avec succès.");
      } else {
        throw Exception(
            "Erreur lors du téléchargement de la base de données : ${response.statusCode}");
      }
    } catch (e) {
      print("Erreur : $e");
      rethrow;
    }
  }

  Future<void> updateLastUpdated(String path) async {
    // Ouvrir la base de données pour la mise à jour
    final db = await openDatabase(path);
    int newLastUpdated = DateTime.now().millisecondsSinceEpoch ~/ 1000;

    // Mettre à jour last_updated dans la table config
    await db.update(
      'config',
      {'last_updated': newLastUpdated},
      where: 'id = ?',
      whereArgs: [1],
    );

    print("last_updated mis à jour à : $newLastUpdated");
  }

  Future<void> ensureDatabaseReady() async {
    // Force l'initialisation si elle n'est pas déjà faite
    await database;
  }
}
