import 'package:dartz/dartz.dart';
import 'package:movi_mobile/core/error/failures.dart';
import '../../domain/entities/movie.dart';
import '../../domain/entities/user.dart';
import '../../domain/repositories/movie_repository.dart';
import '../datasources/remote/movie_remote_datasource.dart';

class MovieRepositoryImpl implements MovieRepository {
  final MovieRemoteDataSource remoteDataSource;

  MovieRepositoryImpl({
    required this.remoteDataSource,
  }) {
    print(
        "MovieRepositoryImpl initialized with remote: $remoteDataSource");
  }

  @override
  Future<Either<Failure, List<Movie>>> getTrendingMovies() async {
    try {
      final movieModels = await remoteDataSource.getTrendingMovies();
      print("Fetched ${movieModels.length} trending movies.");
      final movies = movieModels.map((model) => model.toEntity()).toList();
      return Right(movies);
    } catch (error) {
      print("Error in getTrendingMovies: $error");
      return Left(FetchDataFailure("Failed to fetch trending movies: $error"));
    }
  }
  
  @override
  Future<Either<Failure, void>> addNewMovies() {
    // TODO: implement addNewMovies
    throw UnimplementedError();
  }
  
  @override
  Future<Either<Failure, List<Movie>>> getFavoritesUserMovies(User user) {
    // TODO: implement getFavoritesUserMovies
    throw UnimplementedError();
  }
  
  @override
  Future<Either<Failure, List<Movie>>> getMoviesByCategory(MovieCategory category) {
    // TODO: implement getMoviesByCategory
    throw UnimplementedError();
  }
  
  @override
  Future<Either<Failure, List<Movie>>> getNowPlayingMovies(User user) {
    // TODO: implement getNowPlayingMovies
    throw UnimplementedError();
  }
  
  @override
  Future<Either<Failure, List<Movie>>> searchMovie(String query) {
    // TODO: implement searchMovie
    throw UnimplementedError();
  }
}
