import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:movi_mobile/core/constants/api.dart';
import '../../models/movie_model.dart';

abstract class MovieRemoteDataSource {
  Future<List<MovieModel>> getTrendingMovies();
}

class MovieRemoteDataSourceImpl implements MovieRemoteDataSource {
  MovieRemoteDataSourceImpl(Object object);

  @override
  Future<List<MovieModel>> getTrendingMovies() async {
    List<MovieModel> trendingMovies = [];
    int page = 1;

    while (trendingMovies.length < 10) {
      String url =
          'https://api.themoviedb.org/3/movie/popular?language=en-US&page=$page';
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer ${ApiKeys.tmdbApiKey}',
          'accept': 'application/json',
        },
      ); // Log de la page et du statut

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        // Vérifiez si 'data' et 'results' existent et sont valides
        if (data != null && data['results'] is List) {
          final results = data['results'];

          for (var result in results) {
            if (result != null) {
              int tmdbId = result['id'] ?? -1; // Défaut à -1 si 'id' est null
              bool isHorror = false;
              for (var genre in result['genre_ids']) {
                if (genre == 27) {
                  isHorror = true;
                }
              }
              if (tmdbId != -1 && isHorror == false) {
                Map<String, dynamic> movieData = await getMovieData(tmdbId);
                MovieModel movie = MovieModel.fromJson(movieData);
                trendingMovies.add(movie);
              } else {
                print(
                    'Movie ID is null for result: $result'); // Log d'un ID null
              }
            } else {
              print('Encountered null result'); // Log d'un résultat null
            }
          }

          page++;
        } else {
          print(
              'Unexpected results format or data is null: $data'); // Log d'erreur
          throw Exception('Unexpected results format');
        }
      } else {
        print(
            'Error fetching trending movies: ${response.statusCode}, ${response.body}');
        throw Exception('Failed to load trending movies');
      }
    }
    return trendingMovies;
  }

  Future<Map<String, dynamic>> getMovieData(int tmdb) async {
    Map<String, dynamic> movieData = {};

    String url = 'https://api.themoviedb.org/3/movie/$tmdb?language=fr-FR';
    final response = await http.get(
      Uri.parse(url),
      headers: {
        'Authorization': 'Bearer ${ApiKeys.tmdbApiKey}',
        'accept': 'application/json',
      },
    ); // Log de la page et du statut

    if (response.statusCode == 200) {
      final data = json.decode(response.body);

      if (data != null) {
        movieData['tmdb'] = tmdb;
        movieData['title'] = data['title'];
        int runtime = data['runtime'] as int; // Ensure runtime is an int
        int hours = runtime ~/ 60; // Use integer division operator (~/)
        int minutes = runtime % 60;
        movieData['duration'] = "${hours}h ${minutes}m";
        movieData['synopsis'] = data['overview'];

        final categories = data['genres'];
        List<Map<String, dynamic>> movieCategories = [];
        for (Map<String, dynamic> category in categories) {
          movieCategories.add({"name": category['name'], "id": category['id']});
        }
        movieData['categories'] = movieCategories;
        movieData['added'] = 0;
        movieData['coverWithText'] =
            "https://image.tmdb.org/t/p/original" + data['poster_path'];
        int yearData =
            movieData['release_date'].toString().substring(0, 3) as int;
        movieData['year'] = yearData;
      } else {
        throw Exception('Movie data is null');
      }
    }

    String imagesUrl =
        'https://api.themoviedb.org/3/movie/$tmdb/images?language=null';
    final imagesResponse = await http.get(
      Uri.parse(imagesUrl),
      headers: {
        'Authorization': 'Bearer ${ApiKeys.tmdbApiKey}',
        'accept': 'application/json',
      },
    ); // Log de la page et du statut

    if (response.statusCode == 200) {
      final data = json.decode(imagesResponse.body);

      if (data != null) {
        final backdrops = data['backdrops'];

        for (var backdrop in backdrops) {
          String backdropPath = backdrop['file_path'];
          if (backdropPath.endsWith('.jpg') || backdropPath.endsWith('.png')) {
            movieData['backdrop'] =
                "https://image.tmdb.org/t/p/original$backdropPath";
          }
        }

        final covers = data['posters'];
        for (var cover in covers) {
          String coverPath = cover['file_path'];
          if (coverPath.endsWith('.jpg') || coverPath.endsWith('.png')) {
            movieData['cover'] =
                "https://image.tmdb.org/t/p/original$coverPath";
          }
        }
      }
    }

    return movieData;
  }
}
