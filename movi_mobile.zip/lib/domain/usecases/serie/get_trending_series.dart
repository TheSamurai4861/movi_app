import '../../entities/serie.dart';
import '../../repositories/serie_repository.dart';

class GetTrendingSeries {
  final SerieRepository repository;

  GetTrendingSeries(this.repository);

  Future<List<Serie>> call() {
    return repository.getTrendingSeries();
  }
}
