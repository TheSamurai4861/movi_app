import 'package:dartz/dartz.dart';

import 'package:movi_mobile/core/error/failures.dart';

import '../../entities/movie.dart';
import '../../entities/user.dart';
import '../../repositories/movie_repository.dart';

class GetNowPlayingMovies {
  final MovieRepository repository;

  GetNowPlayingMovies(this.repository);

  Future<Either<Failure, List<Movie>>> call(User user) {
    return repository.getNowPlayingMovies(user);
  }
}
